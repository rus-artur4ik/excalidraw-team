# @artavian/vitest-live-progress-reporter

Vitest 3 reporter that pushes live test progress to the [Live Progress](../README.md) Jenkins plugin.

It recomputes overall and per-file counts by walking the task tree on each update (idempotent under
retries), batches full snapshots on a ~75 ms timer with a guaranteed trailing flush, and sends a
final snapshot when the run finishes.

## Usage

```ts
// vitest.config.ts
import { defineConfig } from "vitest/config";
import LiveProgressReporter from "@artavian/vitest-live-progress-reporter";

export default defineConfig({
  test: {
    reporters: ["default", new LiveProgressReporter()],
  },
});
```

The reporter reads `LIVE_PROGRESS_URL` and `LIVE_PROGRESS_TOKEN` from the environment — both are
injected by the plugin's `withLiveProgress { ... }` pipeline block. **When they are absent the
reporter is a strict no-op**; it never throws, never rejects, and never changes the test run's exit
code. An unreachable endpoint is swallowed with a single warning.

## Development

```bash
npm install
npm test        # vitest run
npm run build   # tsc -> dist/
```
